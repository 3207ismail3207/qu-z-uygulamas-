const express = require('express');
const router = express.Router();
const { Quiz, Question, Option, Category } = require('../models');

// Quiz listesi sayfası
router.get('/quizler', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.redirect('/login');
        }

        const quizzes = await Quiz.findAll({
            include: [
                { model: Category, as: 'category' },
                { model: User, as: 'creator' }
            ]
        });

        res.render('quizzes/list', { 
            title: 'Tüm Quizler',
            quizzes,
            user: req.session.user
        });
    } catch (error) {
        console.error('Quiz listesi yüklenirken hata:', error);
        res.status(500).send('Bir hata oluştu: ' + error.message);
    }
});

// Yeni quiz oluşturma sayfası
router.get('/quiz/olustur', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    
    // Kategorileri çek
    Category.findAll()
        .then(categories => {
            res.render('quizzes/create', { 
                title: 'Yeni Quiz Oluştur',
                categories,
                user: req.session.user
            });
        })
        .catch(error => {
            console.error('Kategoriler yüklenirken hata:', error);
            res.status(500).send('Bir hata oluştu: ' + error.message);
        });
});

// Yeni quiz kaydetme
router.post('/quiz/kaydet', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ 
            success: false, 
            message: 'Oturum açmanız gerekiyor' 
        });
    }

    const transaction = await sequelize.transaction();
    
    try {
        const { title, description, categoryId, timeLimit = 30, questions } = req.body;
        
        // Validasyon
        if (!title || !categoryId || !questions || questions.length === 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Lütfen tüm alanları doldurun ve en az bir soru ekleyin' 
            });
        }

        // Quiz'i oluştur
        const quiz = await Quiz.create({
            title,
            description,
            timeLimit,
            categoryId,
            userId: req.session.user.id,
            isActive: true
        }, { transaction });

        // Soruları ekle
        for (const q of questions) {
            // Soru metni kontrolü
            if (!q.questionText || !q.options || q.options.length === 0) {
                await transaction.rollback();
                return res.status(400).json({ 
                    success: false, 
                    message: 'Lütfen tüm soru alanlarını doldurun' 
                });
            }

            const question = await Question.create({
                questionText: q.questionText,
                quizId: quiz.id,
                points: q.points || 1
            }, { transaction });

            // En az bir doğru cevap kontrolü
            const hasCorrectAnswer = q.options.some(opt => opt.isCorrect);
            if (!hasCorrectAnswer) {
                await transaction.rollback();
                return res.status(400).json({ 
                    success: false, 
                    message: 'Her soru için en az bir doğru cevap seçmelisiniz' 
                });
            }

            // Şıkları ekle
            for (const o of q.options) {
                if (!o.optionText) {
                    await transaction.rollback();
                    return res.status(400).json({ 
                        success: false, 
                        message: 'Lütfen tüm seçenek alanlarını doldurun' 
                    });
                }

                await Option.create({
                    optionText: o.optionText,
                    isCorrect: o.isCorrect || false,
                    questionId: question.id
                }, { transaction });
            }
        }

        await transaction.commit();
        res.json({ 
            success: true, 
            message: 'Quiz başarıyla oluşturuldu',
            quizId: quiz.id 
        });

    } catch (error) {
        await transaction.rollback();
        console.error('Quiz kaydedilirken hata:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Quiz kaydedilirken bir hata oluştu: ' + error.message 
        });
    }
});
module.exports = router;
