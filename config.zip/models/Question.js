const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Question extends Model {
    static associate(models) {
      Question.belongsTo(models.Quiz, { foreignKey: 'quizId' });
      Question.hasMany(models.Option, { foreignKey: 'questionId' });
    }
  }

  Question.init({
    text: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    order: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    quizId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Quizzes',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'Question',
    tableName: 'Questions'
  });

  return Question;
};