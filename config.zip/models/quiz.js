const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Quiz extends Model {
    static associate(models) {
      Quiz.belongsTo(models.User, { foreignKey: 'userId' });
      Quiz.hasMany(models.Question, { foreignKey: 'quizId' });
      Quiz.hasMany(models.QuizAttempt, { foreignKey: 'quizId' });
    }
  }

  Quiz.init({
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: DataTypes.TEXT,
    timeLimit: {
      type: DataTypes.INTEGER,
      defaultValue: 10 // dakika cinsinden
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'Quiz',
    tableName: 'Quizzes'
  });

  return Quiz;
};