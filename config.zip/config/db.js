const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('quiz_db', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false,
    define: {
        timestamps: true,
        underscored: true
    },
    dialectOptions: {
        dateStrings: true,
        typeCast: true,
        supportBigNumbers: true,
        bigNumberStrings: true
    },
    timezone: '+03:00'
});

module.exports = sequelize;