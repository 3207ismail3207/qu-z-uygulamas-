const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Option extends Model {
    static associate(models) {
      Option.belongsTo(models.Question, { foreignKey: 'questionId' });
    }
  }

  Option.init({
    text: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    isCorrect: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    order: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    questionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Questions',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'Option',
    tableName: 'Options'
  });

  return Option;
};