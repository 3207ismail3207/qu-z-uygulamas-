const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class UserAnswer extends Model {
    static associate(models) {
      UserAnswer.belongsTo(models.QuizAttempt, { foreignKey: 'attemptId' });
      UserAnswer.belongsTo(models.Question, { foreignKey: 'questionId' });
      UserAnswer.belongsTo(models.Option, { foreignKey: 'selectedOptionId' });
    }
  }

  UserAnswer.init({
    attemptId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'QuizAttempts',
        key: 'id'
      }
    },
    questionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Questions',
        key: 'id'
      }
    },
    selectedOptionId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'Options',
        key: 'id'
      }
    },
    isCorrect: {
      type: DataTypes.BOOLEAN,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'UserAnswer',
    tableName: 'UserAnswers'
  });

  return UserAnswer;
};