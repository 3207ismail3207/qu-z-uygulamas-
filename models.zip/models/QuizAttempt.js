const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class QuizAttempt extends Model {
    static associate(models) {
      QuizAttempt.belongsTo(models.User, { foreignKey: 'userId' });
      QuizAttempt.belongsTo(models.Quiz, { foreignKey: 'quizId' });
      QuizAttempt.hasMany(models.UserAnswer, { foreignKey: 'attemptId' });
    }
  }

  QuizAttempt.init({
    score: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    timeSpent: {
      type: DataTypes.INTEGER, // saniye cinsinden
      allowNull: false
    },
    completedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    quizId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Quizzes',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'QuizAttempt',
    tableName: 'QuizAttempts'
  });

  return QuizAttempt;
};